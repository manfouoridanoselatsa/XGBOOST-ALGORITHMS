#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <numeric>
#include <fstream>
#include <sstream>
#include <memory>
#include <stack>
#include <random>
#include <thread>
#include <mutex>
#include <sys/time.h>
#include "xgb.h"
#include "bitoniq.h"
#include "utils.cpp"
#include <set>
std::mutex mtx;
std::mutex mtx1;
std::mutex tree_mtx;  
std::mutex stack_mtx;

/* ici on defini les differentes outils qui nous permettrons de calculer le temps d'execution d'un algorithme donne*/
static struct timeval _t1, _t2;
static struct timeval _t3, _t4;
static struct timezone _tz;
static struct timezone _tz1;

#define top1() gettimeofday(&_t1, &_tz)
#define top2() gettimeofday(&_t2, &_tz)

#define top3() gettimeofday(&_t3, &_tz1)
#define top4() gettimeofday(&_t4, &_tz1)

static unsigned long _temps_residuel = 0;
static unsigned long _temps_residuel2 = 0;
void init_cpu_time(void)
{
   top1(); top2();
   _temps_residuel = 1000000L * _t2.tv_sec + _t2.tv_usec -
                     (1000000L * _t1.tv_sec + _t1.tv_usec );
}
void init_cpu_time_2(void)
{
   top3(); top4();
   _temps_residuel2 = 1000000L * _t4.tv_sec + _t4.tv_usec -
                     (1000000L * _t3.tv_sec + _t3.tv_usec );
}
 long cpu_time(void) /* retourne des microsecondes */
{
   return 1000000L * _t2.tv_sec + _t2.tv_usec -
           (1000000L * _t1.tv_sec + _t1.tv_usec- _temps_residuel );
}
 long cpu_time_2(void) /* retourne des microsecondes */
{
   return 1000000L * _t4.tv_sec + _t4.tv_usec -
           (1000000L * _t3.tv_sec + _t3.tv_usec - _temps_residuel2 );
}


/*Ici je defini le constructeur de ma classe permettant de creer un noeud d'un arbre*/
Node::Node(std::vector<int>&  idxs,int depth = 0,double val=0.0,double score =0.0,int var_idx =-1,double split=0.0,int left=-1,int right = -1,bool IsLeaf = false) {

	this->idxs = idxs;
	this->depth = depth;
	this->val = val;
	this->score = score;
	this->var_idx = var_idx;
	this->split = split;
	this->left = left;
	this->right = right;
	this->IsLeaf = IsLeaf;
}


/* Ici Je definis le constructeur de la classe me permettant de creer un arbre */
TreeGenerator::TreeGenerator(std::vector<std::vector<double>>& x, std::vector<double>&  gradient,std::vector<double>& hessian,std::vector<int>& idxs, double subsample_cols = 0.8 , int min_leaf = 1,int min_child_weight = 1 ,int depth = 4,double lambda = 1,double gamma = 1,double eps=0.5,int num_threads=4,int choice=0,int num_bins=3) {
	
	top3();
	this->x = x;
	this->gradient = gradient;
	this->hessian = hessian;
	this->idxs = idxs;
	this->depth = depth;
	this->min_leaf = min_leaf;
	this->lambda = lambda;
	this->gamma  = gamma;
	this->min_child_weight = min_child_weight;
	this->row_count = idxs.size();
	this->col_count = x[1].size(); 
	this->subsample_cols =subsample_cols;
	this->num_threads = num_threads;
	this->choice = choice;
	this->num_bins = num_bins;
	
	if(this->subsample_cols < 1.0){
		//std::cout<<"Hello"<<std::endl;
		this->column_subsample = col_subsample(true);		
	}else{
		this->column_subsample = col_subsample(false);
	}
	top4();
	
	long temps = cpu_time_2();
	printf("\nexecution time = %ld.%03ldms\n\n", temps/1000, temps%1000);
	printf("\n");
	
	this->eps=eps;

	/* Cette Section nous permet de choisir quelle algorihtme l'on veut utiliser dans notre main suivant un chiffre donné */
	switch (choice) {
        case 0: this->find_varsplit_seq(); break;
        case 1: this->find_varsplit_par(); break;
        case 2: this->find_varsplit_par_feat(); break;
    }

	//this->printNode();
	
}

// valeur de sortie d'un noeud donné
inline double TreeGenerator::compute_node_output(int node_idx){
	
	double gradient_sum = 0.0;
	double hessian_sum = 0.0;
	for(int i : tree[node_idx].idxs){
		gradient_sum += this->gradient[i];
		hessian_sum += this->hessian[i];
	}

	return (-gradient_sum/(hessian_sum + lambda));
}

inline double gainNew(double s_Gg,double s_Hg,double s_Gr,double s_Hr, double lambda,double gamma){
	double gain = 0.5*(((s_Gg*s_Gg)/(s_Hg + lambda)) + ((s_Gr*s_Gr)/(s_Hr + lambda)) - (((s_Gg + s_Gr)*(s_Gg + s_Gr))/(s_Hg + s_Hr + lambda)))-gamma;
	return gain;
}

/* Ici je definis la fonction me permettant de choisir aleatoirement un nombre de colonne donne pour creer un arbre*/
std::vector<int> TreeGenerator::col_subsample(bool random_col){
	if(random_col == true){
		// ici on veut faire la selection aleatoire des features a utiliser
		std::vector<int> permutation(this->col_count);
		std::vector<int> selected;

		// On initialise notre vecteur avec les valeurs quelcquonque
		for (int i = 0; i < this->col_count; i++) {
			permutation[i] = i;
		}
		

		// Melangeons de facon aleatoire le contenu de nos vecteurs
		std::random_device rd;
		std::mt19937 g(rd());
		std::shuffle(permutation.begin(), permutation.end(), g);

		// Faire le stockage des valeurs
		selected.reserve(round(this->subsample_cols * this->col_count));
		for(int i = 0; i < round(this->subsample_cols * this->col_count); i++) {
			selected.emplace_back(permutation[i]);
		}
		//std::cout<<selected.size()<<std::endl;
		return selected;
	}else{
		std::vector<int> root_did(this->col_count);
	    std::iota(root_did.begin(), root_did.end(), 0);
	    return root_did;
	}
}


/* Cette fonction est la version séquentielle de l'algorithme Find greedy split en utilisant les feature.
Il ce charge de  réaliser la subdivision pour un noeud donné node_idx en noeud fils gauche et droit*/
void TreeGenerator::find_greedy_split_seq(int node_idx){	
	
	if(tree[node_idx].IsLeaf == true){
		return;
	}
	std::vector<int> lhsF;
	std::vector<int>  rhsF;
	
	int node_tree_size = tree[node_idx].idxs.size();
	if(node_tree_size <= 1 || tree[node_idx].depth >= this->depth){
		tree[node_idx].val = this->compute_node_output(node_idx);
		tree[node_idx].IsLeaf = true;
		return;
	}
	
	for (int c : this->column_subsample){
		std::vector<double> xsplit_1;
		
		// on selectionne les valeurs d'une caracteristiques donnee suivant un certain nombre d'indice
		for (int idx : tree[node_idx].idxs){
			xsplit_1.emplace_back(this->x[idx][c]);
		}
		int xsplit_size = xsplit_1.size();

		std::vector<double> xsplit;
		std::vector<double> xsplit_u_2_2;
		xsplit.emplace_back(xsplit_1[0]);

		for(int i=1;i<xsplit_size;i++){
			bool myBool = false;
			for(int j=0;j<(int)xsplit.size();j++){
				if(xsplit[j] == xsplit_1[i]){
					myBool = true;
					break;
				}
			}
			if(myBool == false){
				xsplit.emplace_back(xsplit_1[i]);
			}	
		}

		std::sort(xsplit.begin(), xsplit.end());
		//tri_bitonique_fusion(xsplit,xsplit.size());
		// std::set<double> xsplit_set(xsplit_1.begin(), xsplit_1.end());
		// std::vector<double> xsplit(xsplit_set.begin(), xsplit_set.end());
		
		for(int i=1;i<(int)xsplit.size();i++){
			xsplit_u_2_2.emplace_back((xsplit[i-1]+xsplit[i])/2.0);
		}
		for(int r = 0; r < (int)xsplit_u_2_2.size(); r++){
			int lhs_sum=0;
			int rhs_sum=0;
			std::vector<int> lhs_indices, rhs_indices;
			double s_Gg = 0.0,s_Hg = 0.0,s_Gr=0.0,s_Hr=0.0;
			
			for (int i = 0; i < xsplit_size; i++){
				if (xsplit_1[i] <= xsplit_u_2_2[r]){
					lhs_sum++;
					lhs_indices.emplace_back(tree[node_idx].idxs[i]);
					s_Gg += this->gradient[tree[node_idx].idxs[i]];
					s_Hg += this->hessian[tree[node_idx].idxs[i]];
					
				}else{
					rhs_sum++;
					rhs_indices.emplace_back(tree[node_idx].idxs[i]);
					s_Gr += this->gradient[tree[node_idx].idxs[i]];
					s_Hr += this->hessian[tree[node_idx].idxs[i]];
				}
			}
			
			/*if (rhs_sum < this->min_leaf || lhs_sum < this->min_leaf || s_Hr <= this->min_child_weight || s_Hg < this->min_child_weight ) {
				continue;
			}*/
			
			double  curr_score = gainNew(s_Gg,s_Hg,s_Gr,s_Hr,this->lambda,this->gamma);
			 
			if (curr_score > tree[node_idx].score && lhs_indices.size() != 0 && rhs_indices.size() != 0){
				tree[node_idx].var_idx = c;
				tree[node_idx].score  = curr_score;
				tree[node_idx].split = xsplit_u_2_2[r];
				lhsF.clear();
				rhsF.clear();
				lhsF = lhs_indices;
				rhsF = rhs_indices;	
			}
			lhs_indices.clear();
			rhs_indices.clear();
		}
		xsplit.clear();
		xsplit_u_2_2.clear();
	}
	
	if(lhsF.size() != 0 && rhsF.size() != 0){
		//ajout des noeuds gauche et droit dans notre arbre
		int left_child_idx = tree.size();
		tree.emplace_back(Node(lhsF,tree[node_idx].depth+1,0.0, 0.0,-1, 0.0, -1,-1));
		int right_child_idx = tree.size();
		tree.emplace_back(Node(rhsF,tree[node_idx].depth+1,0.0, 0.0,-1, 0.0, -1,-1));
		
		//std::cout<<node_idx<<" "<<node_tree_size<<" "<<tree[node_idx].idxs[0]<<" "<<tree[node_idx].idxs[1]<<" "<<tree.size()<<std::endl;
		
		tree[node_idx].left = left_child_idx;
		tree[node_idx].right = right_child_idx;

		node_stack.push(left_child_idx);
		node_stack.push(right_child_idx);
	}else{
		tree[node_idx].val = this->compute_node_output(node_idx);
		tree[node_idx].IsLeaf = true;
	}		
}


/* Cette fonction utilise  la fonction find_greedy_split_seq pour mettre à jour les notre abre en fonction 
des noeud contenu dans la pile node_stack*/
void TreeGenerator::find_varsplit_seq(){
    tree.emplace_back(Node(this->idxs, 0, 0.0,0.0,-1, 0.0, -1,-1));
    node_stack.push(0);
    do{
    	// ici on continu l'entrainnement
    	int node_idx = node_stack.top();
    	node_stack.pop();
    	this->find_greedy_split_seq(node_idx);
    	
    }while(!node_stack.empty());
}

/* Cette fonction est la version parallel de l'algorithme Find greedy split en utilisant les points de subdivision.
Il ce charge de  réaliser la subdivision pour un noeud donné node_idx en noeud fils gauche et droit*/
void TreeGenerator::find_greedy_split_par(int node_idx){
	
	if(tree[node_idx].IsLeaf == true){
		return;
	}
	
	std::vector<int> lhsF;
	std::vector<int>  rhsF;
	
	int node_tree_size = tree[node_idx].idxs.size();

    if (node_tree_size <= 1 || tree[node_idx].depth >= this->depth) {
    	tree[node_idx].val = this->compute_node_output(node_idx);
		tree[node_idx].IsLeaf = true;
        return;
    }

   //int num_threads =this->num_threads;  // Get the number of available cores
    std::vector<std::thread> threads(num_threads);
    
    // Lambda function to process a subset of split points
    auto process_splitPoints = [&](int thread_id){
		for (int c : this->column_subsample){
	        std::vector<double> xsplit_1;
			std::vector<double> xsplit_u_2_2;

	        for (int idx : tree[node_idx].idxs) {
	            xsplit_1.emplace_back(this->x[idx][c]);
	        }
	        int xsplit_size = xsplit_1.size();

	       	std::vector<double> xsplit;
	        xsplit.emplace_back(xsplit_1[0]);
	        for(int i=1;i<xsplit_size;i++){
				bool myBool = false;
				for(int j=0;j<(int)xsplit.size();j++){
					if(xsplit[j] == xsplit_1[i]){
						myBool = true;
						break;
					}
				}
				if(myBool == false){
					xsplit.emplace_back(xsplit_1[i]);
				}	
			}
	        std::sort(xsplit.begin(), xsplit.end());
	        //tri_bitonique_fusion(xsplit,xsplit.size());
	        //std::set<double> xsplit_set(xsplit_1.begin(), xsplit_1.end());
			// std::vector<double> xsplit(xsplit_set.begin(), xsplit_set.end());
			for(int i=1;i<(int)xsplit.size();i++){
				xsplit_u_2_2.emplace_back((xsplit[i-1]+xsplit[i])/2.0);
			}
			
			//xsplit_u_2_2.clear();
	        for (int r = thread_id; r < (int)xsplit_u_2_2.size(); r += num_threads) {
	            int lhs_sum = 0;
	            int rhs_sum = 0;
	            std::vector<int> lhs_indices, rhs_indices;
	            double s_Gg = 0.0,s_Hg = 0.0,s_Gr=0.0,s_Hr=0.0;

	            for (int i = 0; i < xsplit_size; i++){
					if (xsplit_1[i] <= xsplit_u_2_2[r]){
						lhs_sum++;
						lhs_indices.push_back(tree[node_idx].idxs[i]);
						s_Gg += this->gradient[tree[node_idx].idxs[i]];
						s_Hg += this->hessian[tree[node_idx].idxs[i]];
						
					}else{
						rhs_sum++;
						rhs_indices.push_back(tree[node_idx].idxs[i]);
						s_Gr += this->gradient[tree[node_idx].idxs[i]];
						s_Hr += this->hessian[tree[node_idx].idxs[i]];
					}
				}
				
				
				/*if (rhs_sum < this->min_leaf || lhs_sum < this->min_leaf || rhs_hessian_sum <= this->min_child_weight || lhs_hessian_sum < this->min_child_weight ) {
					continue;
				}*/
				
				
				double  curr_score = gainNew(s_Gg,s_Hg,s_Gr,s_Hr,this->lambda,this->gamma);
	            mtx.lock();     
	            if (curr_score > tree[node_idx].score && lhs_indices.size() != 0 && rhs_indices.size() != 0) {
	                tree[node_idx].var_idx = c;
	                tree[node_idx].score = curr_score;
	                tree[node_idx].split = xsplit_u_2_2[r];
	                lhsF = lhs_indices;
	                rhsF = rhs_indices;
	            }
	            mtx.unlock();
	            lhs_indices.clear();
				rhs_indices.clear();
	        }
	        xsplit_u_2_2.clear();
	    
	    }
			//threads.clear();
	};

	// Launch threads
	for (int i = 0; i < num_threads; ++i) {
		threads[i] = std::thread(process_splitPoints, i);
	}

	// Join threads
	for (auto &t : threads) {
		if (t.joinable()) {
			t.join();
		}
	}

    // Add left and right children if the best split is found
    if (!lhsF.empty() && !rhsF.empty()) {
        int left_child_idx = tree.size();
        tree.emplace_back(Node(lhsF, tree[node_idx].depth + 1, 0.0, 0.0, -1, 0.0, -1, -1));
        int right_child_idx = tree.size();
        tree.emplace_back(Node(rhsF, tree[node_idx].depth + 1, 0.0, 0.0, -1, 0.0, -1, -1));

        tree[node_idx].left = left_child_idx;
        tree[node_idx].right = right_child_idx;

        node_stack.push(left_child_idx);
        node_stack.push(right_child_idx);
    }else{
    	tree[node_idx].val = this->compute_node_output(node_idx);
		tree[node_idx].IsLeaf = true;
	}
}


/* Cette fonction utilise  la fonction find_greedy_split_par pour mettre à jour les notre abre en fonction 
des noeud contenu dans la pile node_stack*/
void TreeGenerator::find_varsplit_par(){
    tree.emplace_back(Node(this->idxs, 0, 0.0,0.0,-1, 0.0, -1,-1));
    node_stack.push(0);
    do{
    	// ici on continu l'entrainnement
    	int node_idx = node_stack.top();
    	node_stack.pop();
    	this->find_greedy_split_par(node_idx);
    }while(!node_stack.empty());
}



/* Cette fonction est la version parallel de l'algorithme Find greedy split en utilisant les feature.
Il ce charge de  réaliser la subdivision pour un noeud donné node_idx en noeud fils gauche et droit*/
void TreeGenerator::find_greedy_split_par_feat(int node_idx){
	if(tree[node_idx].IsLeaf == true){
		return;
	}
	
	std::vector<int> lhsF;
	std::vector<int>  rhsF;
	
	int node_tree_size = tree[node_idx].idxs.size();
	
    if (node_tree_size <= 1 || tree[node_idx].depth >= this->depth){    
        tree[node_idx].val = this->compute_node_output(node_idx);
		tree[node_idx].IsLeaf = true;
        return;
    }

    std::vector<std::thread> threads(num_threads);
	int numCol = (int)this->column_subsample.size();
    auto process_column = [&](int thread_id){
		 for (int tt = thread_id; tt < numCol; tt += num_threads){
			int c = this->column_subsample[tt];
			std::vector<double> xsplit_1;
			std::vector<double> xsplit_u_2_2;

			for (int idx : tree[node_idx].idxs){
				xsplit_1.emplace_back(this->x[idx][c]);
			}
			int xsplit_size = xsplit_1.size();

			std::vector<double> xsplit;
			xsplit.emplace_back(xsplit_1[0]);
			for(int i=1;i<xsplit_size;i++){
				bool myBool = false;
				for(int j=0;j<(int)xsplit.size();j++){
					if(xsplit[j] == xsplit_1[i]){
						myBool = true;
						break;
					}
				}
				if(myBool == false){
					xsplit.emplace_back(xsplit_1[i]);
				}	
			}
			//std::sort(xsplit.begin(), xsplit.end());
			tri_bitonique_fusion(xsplit,xsplit.size());
			// std::set<double> xsplit_set(xsplit_1.begin(), xsplit_1.end());
			// std::vector<double> xsplit(xsplit_set.begin(), xsplit_set.end());

			for(int i=1;i<(int)xsplit.size();i++){
				xsplit_u_2_2.emplace_back((xsplit[i-1]+xsplit[i])/2.0);
			}

			for (int r=0;r < (int)xsplit_u_2_2.size();r++) {
				int lhs_sum = 0;
				int rhs_sum = 0;
				std::vector<int> lhs_indices, rhs_indices;
				double s_Gg = 0.0,s_Hg = 0.0,s_Gr=0.0,s_Hr=0.0;

				for (int i = 0; i < xsplit_size; i++){
					if (xsplit_1[i] <=  xsplit_u_2_2[r]){
						lhs_sum++;
						lhs_indices.push_back(tree[node_idx].idxs[i]);
						s_Gg += this->gradient[tree[node_idx].idxs[i]];
						s_Hg += this->hessian[tree[node_idx].idxs[i]];
						
					}else{
						rhs_sum++;
						rhs_indices.push_back(tree[node_idx].idxs[i]);
						s_Gr += this->gradient[tree[node_idx].idxs[i]];
						s_Hr += this->hessian[tree[node_idx].idxs[i]];
					}
				}
				
				
				/*if (rhs_sum < this->min_leaf || lhs_sum < this->min_leaf || rhs_hessian_sum <= this->min_child_weight || lhs_hessian_sum < this->min_child_weight ) {
					continue;
				}*/
				
				
				double  curr_score = gainNew(s_Gg,s_Hg,s_Gr,s_Hr,this->lambda,this->gamma);
				 
				// Protect shared variables with mutex
				mtx1.lock();
				if (curr_score > tree[node_idx].score && lhs_indices.size() != 0 && rhs_indices.size() != 0) {
					tree[node_idx].var_idx = c;
					tree[node_idx].score = curr_score;
					tree[node_idx].split = xsplit_u_2_2[r];
					lhsF = lhs_indices;
					rhsF = rhs_indices;
				}
				mtx1.unlock();
				
				lhs_indices.clear();
				rhs_indices.clear();
			}
			xsplit_u_2_2.clear();
		 }
    };

    // Launch threads using modulo parallelization
    for (int i = 0; i < num_threads; ++i) {
        threads[i] = std::thread(process_column, i);
    }

    // Join threads
    for (auto &t : threads) {
        if (t.joinable()) {
            t.join();
        }
    }
    threads.clear();
    // Add left and right children if the best split is found
    if (!lhsF.empty() && !rhsF.empty()) {
        int left_child_idx = tree.size();
        tree.emplace_back(Node(lhsF, tree[node_idx].depth + 1, 0.0, 0.0, -1, 0.0, -1, -1));
        int right_child_idx = tree.size();
        tree.emplace_back(Node(rhsF, tree[node_idx].depth + 1, 0.0, 0.0, -1, 0.0, -1, -1));

        tree[node_idx].left = left_child_idx;
        tree[node_idx].right = right_child_idx;
        node_stack.push(left_child_idx);
        node_stack.push(right_child_idx);
    }else{
 		tree[node_idx].val = this->compute_node_output(node_idx);
		tree[node_idx].IsLeaf = true;
 	}   
}



/* Cette fonction utilise  la fonction find_greedy_split_par_feat pour mettre à jour les notre abre en fonction 
des noeud contenu dans la pile node_stack*/
void TreeGenerator::find_varsplit_par_feat(){
    tree.emplace_back(Node(this->idxs,  0, 0.0,0.0,-1, 0.0, -1,-1));
    node_stack.push(0);
    
    do{
    	// ici on continu l'entrainnement
    	int node_idx = node_stack.top();
    	node_stack.pop();
    	this->find_greedy_split_par_feat(node_idx);
    	
    }while(!node_stack.empty());
}




/* Cette fonction permet de realiser la prediction pour un arbre donné*/
std::vector<double> TreeGenerator::predict(std::vector<std::vector<double>>& x) {
    int x_size = x.size();
    std::vector<double> y_pred(x_size);
	std::vector<std::thread> threads(num_threads);

    auto worker = [&](int thread_id){
		for (int i = thread_id; i < x_size; i += num_threads) {
			y_pred[i] = this->predict_row(x[i]);
		}
	};
	
	for (int r = 0; r < num_threads; r++){
		threads[r] = std::thread(worker, r);
	}

	for(auto &t : threads){
		if (t.joinable()){
			t.join();
		}
	}

    return y_pred;
}


/* Cette fonction est un utilitaire utilisé par la fonction predict ci haut pour recuperer la valeur  du noeud feuille 
à laquelle correspond un individus*/
double TreeGenerator::predict_row(std::vector<double>& xi){
	int node_idx = 0;
	Node node = tree[node_idx];
	int tree_size = tree.size();
	for(int i=0;i<tree_size;i++){
		
		if(tree[node_idx].var_idx == -1 /*&& tree[node_idx].val >= 0.0*/){
			return tree[node_idx].val;
		}else{
			if(xi[node.var_idx]<= node.split){
				node_idx = node.left;
			}else{
				node_idx = node.right;
			}
		}
		node = tree[node_idx];
	}
	return 0.0;
}


/* Permet d'afficher notre arbre de décision créé*/
void TreeGenerator::printNode(){
	for(int i=0;i<(int)tree.size();i++){
		std::cout<< i<< " "<<tree[i].val<<" ";
		for(int j=0;j<(int)tree[i].idxs.size();j++){
			std::cout<<tree[i].idxs[j]<<" ";	
		}
		std::cout<<" "<<tree[i].var_idx<<" "<<tree[i].score;
		std::cout<<std::endl;
	}
}


/* Nous permet de calculer la fonction sigmoid*/
double XGBoostClassifier::sigmoid(double x){
	//return  std::exp(x) / (1.0 + std::exp(x));
	return 1.0 / (1.0 + std::exp(-x));
}


/* Nous permet de calculer les gradients et les hessiens de chaque individus*/	
void XGBoostClassifier::grad_hess(std::vector<double>& preds,std::vector<int>& labels,std::vector<double> & grads,std::vector<double> & hess){
	int label_size = labels.size();
	std::vector<std::thread> threads(num_threads);
	auto worker = [&](int thread_id){
		for(int i = thread_id;i< label_size;i+= num_threads){
			double  residual =(this->sigmoid(preds[i]) - labels[i]);
			double  den = this->sigmoid(preds[i]) * (1.0-this->sigmoid(preds[i]));
			
			grads[i] = (residual);
			hess[i] = (den);
			
		}
	};
	
	for (int r = 0; r < num_threads; r++){
		threads[r] = std::thread(worker, r);
	}

	for(auto &t : threads){
		if (t.joinable()){
			t.join();
		}
	}

}


/* Nous permet au besoin de calculer notre modele initial f_0*/
double XGBoostClassifier::log_odds(std::vector<int> labels){
	int yesCount,noCount;
	int label_size = labels.size();
	
	for(int i=0;i<label_size;i++){
		if(labels[i] == 1){
			yesCount +=1;
		}else{
			noCount +=1;
		}
	}
	return std::log(yesCount/noCount);
}
		

/* Nous permet de tirer aleatoirement un pourcentage d'individus
 pour  creer un arbre donné*/
void XGBoostClassifier::observation_subsample(std::vector<std::vector<double>>& x,std::vector<int>& y,double subsample_ratio,bool random_sample){
	int x_size  = x.size();
	if(random_sample == true){
		// ici on veut faire la selection aleatoire des features a utiliser
		std::vector<int> permutation(x_size);
		// On initialise notre vecteur avec les valeurs quelcquonque
		for (int i = 0; i < x_size; i++) {
			permutation[i] = i;
		}
		
		std::vector<int>  y_;
		// Melangeons de facon aleatoire le contenu de nos vecteurs
		std::random_device rd;
		std::mt19937 g(rd());
		std::shuffle(permutation.begin(), permutation.end(), g);
		
		// Faire le stockage des valeurs
		std::vector<std::vector<double>> selected;
		
		for(int i = 0; i < round(subsample_ratio * x_size); i++){
			selected.push_back(x[permutation[i]]);
			
			y_.push_back(y[permutation[i]]);
		}
		//std::cout<<" Hello "<<selected.size()<<std::endl;
		
		this->x = selected;
		this->y = y_;
		
	}else{
    	this->x = x;
    	this->y = y;
	}
}


/*Cette fontion ce charge de creer notre modele
 XGOOST suivant l'algorithme choisit */
std::vector<double>  XGBoostClassifier::fit(std::vector<std::vector<double>>& x, std::vector<int>& y,double subsample_cols = 0.8 , int min_child_weight = 1, int depth = 8,int min_leaf = 1,double learning_rate = 0.4, int trees = 5,double lambda = 1, double gamma = 1,double eps=0.5,int num_threads=4,int choice=0,int num_bins=3){
	observation_subsample(x,y,0.5,false);    
    int x_size  = (this->x).size();
	
	std::vector<double> base_pred(x_size, 0.5);
	this->base_pred = base_pred;
	
	std::vector<int> root_idxs(x_size);
    std::iota(root_idxs.begin(), root_idxs.end(), 0);
    	
	this->depth=depth;
	this->subsample_cols = subsample_cols;
	this->min_child_weight = min_child_weight;
	this->min_leaf = min_leaf;
	this->learning_rate = learning_rate;
	this->trees = trees;
	this->lambda = lambda;
	this->num_bins = num_bins;
	this->gamma = gamma;
	this->num_threads = num_threads;
	this->min_child_weight = min_child_weight;
	
	std::string outputFileName= "outputTreePerTime"+std::to_string(choice)+".csv";
	std::ofstream csvFile(outputFileName, std::ios::out);

	// Check if the file was opened successfully
	if (!csvFile.is_open()) {
		std::cerr << "Error: Unable to open the CSV file." << std::endl;
	}
	// Write the header row
	csvFile << "NumArbre,ExecutionTime" << std::endl;
	double temps_double_data = 0;
	std::vector<double> loss;
	
	for(int treeUnit = 0; treeUnit < this->trees; treeUnit++){
		std::cout<<"Tree Number:"<<treeUnit<<std::endl;
		std::vector<double> Grad(x_size,0.0),Hess(x_size,0.0);
		grad_hess(this->base_pred,this->y,Grad,Hess);
		init_cpu_time();
		top1();
		TreeGenerator tree(this->x, Grad, Hess,root_idxs,this->subsample_cols, this->min_leaf,this->min_child_weight, this->depth, this->lambda, this->gamma,eps,num_threads,choice,this->num_bins);
		top2();
		long temps = cpu_time();
		temps_double_data += temps/1000.0 + (0.0001*(temps%1000));

		csvFile <<treeUnit<<","<<temps_double_data<< std::endl;
		std::vector<double> y_pred = tree.predict(this->x);
		
		for (int i = 0; i < x_size; i++) {
			this->base_pred[i]  += this->learning_rate * y_pred[i];
		}
		
		this->estimators.emplace_back(tree);
		
		double loss_value = 0.0;
		
		double sum_squared_error = 0.0;
		for (int i = 0; i < x_size; i++) {
			double error = y[i] - y_pred[i];
			sum_squared_error += error * error;
		}

		double mean_squared_error = sum_squared_error / x_size;
		loss_value=sqrt(mean_squared_error);
		
		//std::cout<<"\n"<<loss_value<<"\n";
		loss.push_back(loss_value);
		y_pred.clear();
		Grad.clear();
		Hess.clear();
	}
	
	// Fermer le fichier
	csvFile.close();
	base_pred.clear();
	root_idxs.clear();

	
	return loss;
}


/* Nous permet de calculer les predictions de 
notre jeux de test en retournant les valeurs sous forme de probabilité*/
std::vector<double> XGBoostClassifier::predict_proba(std::vector<std::vector<double>> x){
	int x_size = x.size();
	std::vector<double> pred(x_size,0);
	std::vector<double> sigmoid_input(x_size, 0.0);
	
	std::vector<std::thread> threads(num_threads);
	for (auto& estimator : this->estimators) {
		std::vector<double> estimator_pred =estimator.predict(x);
		auto worker = [&](int thread_id){
			for (int i = thread_id; i < x_size; i += num_threads) {
				pred[i] += this->learning_rate*estimator_pred[i];
				sigmoid_input[i] = this->sigmoid(pred[i]);
			}
		};
		
		for (int r = 0; r < num_threads; r++){
			threads[r] = std::thread(worker, r);
		}

		for(auto &t : threads){
			if (t.joinable()){
				t.join();
			}
		}

    }
    
	pred.clear();
	return sigmoid_input;
}

int main(int argc, char * argv[]) {
	init_cpu_time_2();
   
   	if(argc != 17){
		printf("Nombre d'argument incorrect\n");
		printf("Format de l'executable: <<nom fichier>> <<nombre-thread>> <<fichier-dataset>> <<fichier-labels>> <<train-test-percent>> <<subsample_cols>> <<min_child_weight>> <<depth>> <<min_leaf>> <<learning_rate>> <<trees>> <<lambda>> <<gamma>> <<epsilon>> <<ValeurNAOuPas>> <<choixAlgo>> <<choix algo>> <<numbins>>\n");
		exit(-1);
	}
	
	// Declatration des parametres utilisateurs
	int num_threads = atoi(argv[1]);
	std::string filename_dataset = argv[2];
	std::string filename_labels = argv[3];
    double train_test_percent= std::stod(argv[4]);
	double subsample_cols_percent= std::stod(argv[5]);
	int  min_child_weight_arg =  atoi(argv[6]);
	int depth_arg = atoi(argv[7]);
	int min_leaf_arg = atoi(argv[8]);
	double learning_rate_arg = std::stod(argv[9]);
	int num_trees = atoi(argv[10]);
	double lambda_arg = std::stod(argv[11]);
	double gamma_arg = std::stod(argv[12]);
	double eps = std::stod(argv[13]);
	std::string nanOrNot = argv[14];
	int choice = atoi(argv[15]);
	int num_bins =  atoi(argv[16]);

	std::vector<std::vector<double>> x;
	std::vector<std::vector<double>> yTemp;
	if(nanOrNot != "oui"){
		x = extractCSVDataset(filename_dataset);
		yTemp = extractCSVDataset(filename_labels);
	}else{
		x = extractCSVDatasetWithNa(filename_dataset);
		yTemp = extractCSVDatasetWithNa(filename_labels);
	}
	

	std::vector<int> y;

	for(int i=0; i<(int)yTemp.size();i++){
		y.push_back(((int)yTemp[i][0]));
	}

	auto [x_train, xTest, y_train, yTest] = train_test_split(x, y, train_test_percent);
	/*std::vector<std::vector<double>> x_train = extractCSVDataset("Datasets/xtrain.csv");
	std::vector<std::vector<double>> xTest = extractCSVDataset("Datasets/xtest.csv");

	std::vector<std::vector<double>> y_trainTemp = extractCSVDataset("Datasets/ytrain.csv");
	std::vector<std::vector<double>> y_testTemp = extractCSVDataset("Datasets/ytest.csv");

	std::vector<int> y_train;
	for(int i=0; i<(int)y_trainTemp.size();i++){
	 	y_train.push_back(((int)y_trainTemp[i][0]));
    }

	std::vector<int> yTest;
	for(int i=0; i<(int)y_testTemp.size();i++){
		yTest.push_back(((int)y_testTemp[i][0]));
    }*/
	// execution sequentielle
	std::cout<<"execution in progress..."<<std::endl;
	XGBoostClassifier xgb;
	top3();
	std::vector<double> loss = xgb.fit(x_train,y_train,subsample_cols_percent,min_child_weight_arg,
	depth_arg,min_leaf_arg,learning_rate_arg,num_trees,lambda_arg, gamma_arg,eps,num_threads,choice,num_bins);
	top4();
	
	long temps = cpu_time_2();
	printf("\nexecution time = %ld.%03ldms\n\n", temps/1000, temps%1000);
	printf("\n");
	
	
	std::string outputFileNameLoss= "outputPerLossPerTree.csv";
	std::ofstream csvFileLoss(outputFileNameLoss, std::ios::out);
	// Check if the file was opened successfully
	if (!csvFileLoss.is_open()) {
		std::cerr << "Error: Unable to open the CSV file." << std::endl;
		return 1;
	}
	
	int loss_size = loss.size();
	for(int i=0;i<loss_size;i++){
		csvFileLoss<<i<<","<<loss[i]<< std::endl;
	}
	csvFileLoss.close();

	//prediction des donnees de test
	std::vector<double>predicted_labels= xgb.predict_proba(xTest);

	int confusionSize = 4 ;

	std::ofstream logFileResult("resultLog.txt", std::ios::app);
	// Check if the file was opened successfully
	if(!logFileResult.is_open()) {
		std::cerr << "Error: Unable to open the CSV file." << std::endl;
		return 1;
	}
	std::vector<int> confusion_matrix(confusionSize,0);
	confusion_matrix = calculate_confusion_matrix(yTest, predicted_labels, yTest.size(), confusion_matrix);

	logFileResult<<argv[0]<<" "<<num_threads<<" "<<filename_dataset<<" "<<filename_labels<<" "<<train_test_percent<<" "<<subsample_cols_percent<<" "<<min_child_weight_arg<<" "<<depth_arg<<" "<<min_leaf_arg<<" "<<learning_rate_arg<<" "<<num_trees<<" "<<lambda_arg<<" "<<gamma_arg<<" "<<eps<<" "<<nanOrNot<<" "<<choice<<" "<<num_bins<<std::endl;

	print_confusion_matrix(confusion_matrix,logFileResult);
	double accuracy = calculate_accuracy(confusion_matrix);
	printf("\n\nAccuracy: %.2f%%\n", accuracy*100);
	logFileResult<<"Accuracy:"<<accuracy*100<< std::endl;
	double precision = calculate_precision(confusion_matrix);
	printf("Precision: %.2f%%\n", precision*100);
	logFileResult<<"Precision:"<<precision*100<< std::endl;
	double recall = calculate_recall(confusion_matrix);
	printf("Recall: %.2f%%\n", recall*100);
	logFileResult<<"Recall:"<<recall*100<< std::endl;
	logFileResult<<"execution time:"<< temps/1000<<"."<<temps%1000<<"ms"<<std::endl;
	logFileResult<<"-----------------------------------------------------------------------------------------"<< std::endl;
	logFileResult.close();

    return 0;
}
