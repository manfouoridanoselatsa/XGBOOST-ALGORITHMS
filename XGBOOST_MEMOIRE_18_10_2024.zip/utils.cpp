/* Nous permet d'extraire les données de notre jeux de données*/
std::vector<std::vector<double>> extractCSVDataset(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cout << "Failed to open file: " << filename << std::endl;
        exit(0);
    }

    std::string line;
    std::vector<std::vector<double>> row;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string value;
        
        std::vector<double> rowLine;
        while (std::getline(iss, value, ',')) {
            rowLine.push_back(std::stod(value));
        }
        row.push_back(rowLine);
        rowLine.clear();

    }
    file.close();
    return row;
}    



/* Nous permet d'extraire les données de notre jeux de données avec prise en compte des valeurs NA*/
std::vector<std::vector<double>> extractCSVDatasetWithNa(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cout << "Failed to open file: " << filename << std::endl;
        exit(0);
    }

    std::string line;
    std::vector<std::vector<double>> row;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string value;
        std::vector<std::string> fields;
        std::vector<double> rowLine;
        while (std::getline(iss, value, ',')){
			if(value.empty() || value == "NaN" || value== "NA" || value == "null"){
				rowLine.push_back(-0.00000000000000001);
			}else{
            	rowLine.push_back(std::stod(value));
			}
        }
        row.push_back(rowLine);
        rowLine.clear();

    }
    file.close();
    return row;
}  


/* Calcul de la matrice de confusion */
std::vector<int> calculate_confusion_matrix(std::vector<int> true_labels, std::vector<double> predicted_labels, int num_samples, std::vector<int> confusion_matrix) {
    for (int i = 0; i < num_samples; i++) {
        int true_label = true_labels[i];
        int predicted_label = 0;
        
        if(predicted_labels[i] >= 0.5){
        	predicted_label = 1;
        }else{
        	predicted_label = 0;
        }
        
        confusion_matrix[true_label * 2 + predicted_label]++;
    }
    
    return  confusion_matrix;
}




void print_confusion_matrix(std::vector<int> confusion_matrix,std::ofstream &logFileResult) {
    printf("Confusion Matrix:\n");
	logFileResult<<"Confusion Matrix:"<<std::endl;
    printf("          Predicted\n");
	logFileResult<<"          Predicted"<<std::endl;
    printf("          0     1\n");
	logFileResult<<"          0     1"<<std::endl;
    printf("Actual 0  %d     %d\n", confusion_matrix[0], confusion_matrix[1]);
	logFileResult<<"          "<<confusion_matrix[0]<<"     "<<confusion_matrix[1]<<std::endl;
    printf("       1  %d     %d\n", confusion_matrix[2], confusion_matrix[3]);
	logFileResult<<"          "<<confusion_matrix[2]<<"     "<<confusion_matrix[3]<<std::endl;
}

void calculate_metrics(std::vector<int> true_labels, std::vector<double> predicted_labels, int num_samples){
	// Initialize counters for precision and recall calculations
    int true_positive = 0;
    int false_positive = 0;
    int false_negative = 0;
    int true_negative = 0;

    // Calculate accuracy, precision, and recall
    for (int i = 0; i < num_samples; ++i) {
        // Round the prediction to get binary output (0 or 1)
        int predicted_label = round(predicted_labels[i]);
        int actual_label = (int)true_labels[i];

        if (predicted_label == 1 && actual_label == 1) {
            true_positive++;
        } else if (predicted_label == 1 && actual_label == 0) {
            false_positive++;
        } else if (predicted_label == 0 && actual_label == 1) {
            false_negative++;
        } else if (predicted_label == 0 && actual_label == 0) {
            true_negative++;
        }
    }

    // Calculate precision, recall, and accuracy
    float precision = true_positive / (float)(true_positive + false_positive);
    float recall = true_positive / (float)(true_positive + false_negative);
    float accuracy = (true_positive + true_negative) / (float)(true_positive + false_positive+true_negative+false_negative);

    // Print the results
    printf("Accuracy: %.2f%%\n", accuracy * 100.0);
    printf("Precision: %.2f%%\n", precision * 100.0);
    printf("Recall: %.2f%%\n", recall * 100.0);
}

double calculate_accuracy(std::vector<int> confusion_matrix) {
    int true_positive = confusion_matrix[3];
    int true_negative = confusion_matrix[0];
    int total_samples = true_positive + true_negative+confusion_matrix[1]+confusion_matrix[2];
    printf("Individus: %d\n", total_samples);
    double accuracy = (double)(true_positive + true_negative) / total_samples;
    return accuracy;
}

double calculate_recall(std::vector<int> confusion_matrix) {
    int true_positive = confusion_matrix[3];
    //int true_negative = confusion_matrix[0];
    int false_negative = confusion_matrix[1];
    double recall = (double)(true_positive)/(true_positive+false_negative);
    return recall;
}

double calculate_precision(std::vector<int> confusion_matrix){
    int true_positive = confusion_matrix[3];
    //int true_negative = confusion_matrix[0];
    int false_positive = confusion_matrix[2];
    double precision = (double)(true_positive)/(true_positive+false_positive);
    return precision;
}


/* Fonction de train test split*/
std::tuple<std::vector<std::vector<double>>, std::vector<std::vector<double>>, std::vector<int>, std::vector<int>> train_test_split(const std::vector<std::vector<double>>& X, const std::vector<int>& y, double test_size = 0.2, unsigned seed = 0) {

    // Check if sizes of X and y match
    if (X.size() != y.size()) {
        throw std::invalid_argument("X and y must have the same number of elements.");
    }

    // Create a vector of indices and shuffle it
    std::vector<int> indices(X.size());
    std::iota(indices.begin(), indices.end(), 0);
    std::shuffle(indices.begin(), indices.end(), std::default_random_engine(seed));

    // Determine the splitting point
    int test_count = static_cast<int>(X.size() * test_size);
    int train_count = X.size() - test_count;

    // Create the train and test sets
    std::vector<std::vector<double>> X_train, X_test;
	std::vector<int>  y_train, y_test;
    for (int i = 0; i < train_count; ++i) {
        X_train.push_back(X[indices[i]]);
        y_train.push_back(y[indices[i]]);
    }
    for (int i = train_count; i < (int)X.size(); ++i) {
        X_test.push_back(X[indices[i]]);
        y_test.push_back(y[indices[i]]);
    }

    return make_tuple(X_train, X_test, y_train, y_test);
}

/* Cette fonction est un utilitaire que nous allons utiliser
pour comparer les éléments de type feature_val*/
bool compareByVal(const feature_val& a, const feature_val& b) {
    if (a.value == b.value) {
        return a.idx > b.idx; // Si les âges sont égaux, trier par nom
    }
    return a.value <= b.value; // Trier par âge
}


